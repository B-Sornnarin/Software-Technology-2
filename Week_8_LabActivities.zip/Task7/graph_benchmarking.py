# graph_benchmarking.py

from graph import Graph
import time
import random

def benchmark_graph_operations(num_vertices, num_edges):
    """Benchmark graph operations for a given size"""
    print(f"\n--- Benchmark: {num_vertices} vertices, {num_edges} edges ---")
    
    g = Graph(directed=False, weighted=False)
    
    # Benchmark adding vertices
    start_time = time.time()
    for i in range(num_vertices):
        g.add_vertex(str(i))
    vertex_time = time.time() - start_time
    print(f"  Added {num_vertices} vertices in {vertex_time:.6f} seconds")
    
    # Benchmark adding edges
    start_time = time.time()
    edges_added = 0
    for _ in range(num_edges):
        v1 = str(random.randint(0, num_vertices - 1))
        v2 = str(random.randint(0, num_vertices - 1))
        if v1 != v2:
            g.add_edge(v1, v2)
            edges_added += 1
    edge_time = time.time() - start_time
    print(f"  Added {edges_added} edges in {edge_time:.6f} seconds")
    
    # Benchmark BFS from vertex '0'
    if '0' in g.graph:
        start_time = time.time()
        g.bfs('0')
        bfs_time = time.time() - start_time
        print(f"  BFS completed in {bfs_time:.6f} seconds")
    else:
        print("  Vertex '0' not found for BFS")
    
    # Benchmark DFS from vertex '0'
    if '0' in g.graph:
        start_time = time.time()
        g.dfs('0')
        dfs_time = time.time() - start_time
        print(f"  DFS completed in {dfs_time:.6f} seconds")
    else:
        print("  Vertex '0' not found for DFS")
    
    return {
        'vertices': num_vertices,
        'edges': edges_added,
        'vertex_time': vertex_time,
        'edge_time': edge_time,
        'bfs_time': bfs_time,
        'dfs_time': dfs_time
    }


def benchmark_multiple_sizes():
    """Run benchmarks for different graph sizes"""

    print("GRAPH OPERATIONS BENCHMARKING")

    
    # Test different sizes
    test_sizes = [
        (10, 20),      # 10 vertices, 20 edges
        (50, 100),     # 50 vertices, 100 edges
        (100, 200),    # 100 vertices, 200 edges
        (200, 500),    # 200 vertices, 500 edges
        (500, 1000),   # 500 vertices, 1000 edges
        (1000, 3000)   # 1000 vertices, 3000 edges
    ]
    
    results = []
    for vertices, edges in test_sizes:
        result = benchmark_graph_operations(vertices, edges)
        results.append(result)
    
    # Print summary

    print("SUMMARY")

    print(f"{'Vertices':<10} {'Edges':<10} {'Add V (s)':<12} {'Add E (s)':<12} {'BFS (s)':<12} {'DFS (s)':<12}")

    
    for r in results:
        print(f"{r['vertices']:<10} {r['edges']:<10} {r['vertex_time']:<12.6f} {r['edge_time']:<12.6f} {r['bfs_time']:<12.6f} {r['dfs_time']:<12.6f}")
    

    print("Benchmarking Complete!")


def benchmark_directed_vs_undirected():
    """Compare directed vs undirected graph performance"""

    print("DIRECTED vs UNDIRECTED GRAPH COMPARISON")

    
    num_vertices = 500
    num_edges = 1000
    
    # Undirected graph
    print(f"\n--- Undirected Graph ({num_vertices} vertices, {num_edges} edges) ---")
    g_undirected = Graph(directed=False, weighted=False)
    
    start_time = time.time()
    for i in range(num_vertices):
        g_undirected.add_vertex(str(i))
    for _ in range(num_edges):
        v1 = str(random.randint(0, num_vertices - 1))
        v2 = str(random.randint(0, num_vertices - 1))
        if v1 != v2:
            g_undirected.add_edge(v1, v2)
    build_time = time.time() - start_time
    print(f"  Build time: {build_time:.6f} seconds")
    
    start_time = time.time()
    g_undirected.bfs('0')
    bfs_time = time.time() - start_time
    print(f"  BFS time: {bfs_time:.6f} seconds")
    
    # Directed graph
    print(f"\n--- Directed Graph ({num_vertices} vertices, {num_edges} edges) ---")
    g_directed = Graph(directed=True, weighted=False)
    
    start_time = time.time()
    for i in range(num_vertices):
        g_directed.add_vertex(str(i))
    for _ in range(num_edges):
        v1 = str(random.randint(0, num_vertices - 1))
        v2 = str(random.randint(0, num_vertices - 1))
        if v1 != v2:
            g_directed.add_edge(v1, v2)
    build_time = time.time() - start_time
    print(f"  Build time: {build_time:.6f} seconds")
    
    start_time = time.time()
    g_directed.bfs('0')
    bfs_time = time.time() - start_time
    print(f"  BFS time: {bfs_time:.6f} seconds")


def benchmark_weighted_vs_unweighted():
    """Compare weighted vs unweighted graph performance"""

    print("WEIGHTED vs UNWEIGHTED GRAPH COMPARISON")

    
    num_vertices = 500
    num_edges = 1000
    
    # Unweighted graph
    print(f"\n--- Unweighted Graph ({num_vertices} vertices, {num_edges} edges) ---")
    g_unweighted = Graph(directed=False, weighted=False)
    
    start_time = time.time()
    for i in range(num_vertices):
        g_unweighted.add_vertex(str(i))
    for _ in range(num_edges):
        v1 = str(random.randint(0, num_vertices - 1))
        v2 = str(random.randint(0, num_vertices - 1))
        if v1 != v2:
            g_unweighted.add_edge(v1, v2)
    build_time = time.time() - start_time
    print(f"  Build time: {build_time:.6f} seconds")
    
    # Weighted graph
    print(f"\n--- Weighted Graph ({num_vertices} vertices, {num_edges} edges) ---")
    g_weighted = Graph(directed=False, weighted=True)
    
    start_time = time.time()
    for i in range(num_vertices):
        g_weighted.add_vertex(str(i))
    for _ in range(num_edges):
        v1 = str(random.randint(0, num_vertices - 1))
        v2 = str(random.randint(0, num_vertices - 1))
        weight = random.randint(1, 100)
        if v1 != v2:
            g_weighted.add_edge(v1, v2, weight)
    build_time = time.time() - start_time
    print(f"  Build time: {build_time:.6f} seconds")


if __name__ == "__main__":
    # Run single benchmark
    print("Single Benchmark Test")
    benchmark_graph_operations(100, 200)
    
    # Run multiple size benchmarks
    benchmark_multiple_sizes()
    
    # Compare directed vs undirected
    benchmark_directed_vs_undirected()
    
    # Compare weighted vs unweighted
    benchmark_weighted_vs_unweighted()
