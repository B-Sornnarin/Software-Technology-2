# graph_tester.py - Task 3 Only

from graph import Graph


print("TASK 3: DFS Traversal")


#  DFS Test 1: Simple linear graph 
print("\n--- DFS Test 1: Linear Graph (A-B-C-D) ---")
dfs_graph1 = Graph(directed=False)
for v in ['A', 'B', 'C', 'D']:
    dfs_graph1.add_vertex(v)
dfs_graph1.add_edge('A', 'B')
dfs_graph1.add_edge('B', 'C')
dfs_graph1.add_edge('C', 'D')

print("Graph structure:")
dfs_graph1.print_graph()

print("\nBFS starting from vertex 'A':")
visited_bfs = dfs_graph1.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)

print("\nDFS starting from vertex 'A':")
visited_dfs = dfs_graph1.dfs('A')
print("Visited vertices in DFS order:", visited_dfs)



#  DFS Test 2: Graph with branches 
print("\n--- DFS Test 2: Graph with Branches ---")
dfs_graph2 = Graph(directed=False)
for v in ['A', 'B', 'C', 'D', 'E', 'F']:
    dfs_graph2.add_vertex(v)
dfs_graph2.add_edge('A', 'B')
dfs_graph2.add_edge('A', 'C')
dfs_graph2.add_edge('B', 'D')
dfs_graph2.add_edge('B', 'E')
dfs_graph2.add_edge('C', 'F')

print("Graph structure:")
dfs_graph2.print_graph()

print("\nBFS starting from vertex 'A':")
visited_bfs2 = dfs_graph2.bfs('A')
print("Visited vertices in BFS order:", visited_bfs2)

print("\nDFS starting from vertex 'A':")
visited_dfs2 = dfs_graph2.dfs('A')
print("Visited vertices in DFS order:", visited_dfs2)



#  DFS Test 3: Graph with cycle 
print("\n--- DFS Test 3: Graph with Cycle (Triangle) ---")
dfs_graph3 = Graph(directed=False)
for v in ['A', 'B', 'C']:
    dfs_graph3.add_vertex(v)
dfs_graph3.add_edge('A', 'B')
dfs_graph3.add_edge('B', 'C')
dfs_graph3.add_edge('C', 'A')  # Creates a cycle

print("Graph structure:")
dfs_graph3.print_graph()

print("\nBFS starting from vertex 'A':")
visited_bfs3 = dfs_graph3.bfs('A')
print("Visited vertices in BFS order:", visited_bfs3)

print("\nDFS starting from vertex 'A':")
visited_dfs3 = dfs_graph3.dfs('A')
print("Visited vertices in DFS order:", visited_dfs3)



#  DFS Test 4: Directed graph 
print("\n--- DFS Test 4: Directed Graph (A->B, A->C, B->D) ---")
dfs_graph4 = Graph(directed=True)
for v in ['A', 'B', 'C', 'D']:
    dfs_graph4.add_vertex(v)
dfs_graph4.add_edge('A', 'B')
dfs_graph4.add_edge('A', 'C')
dfs_graph4.add_edge('B', 'D')

print("Graph structure:")
dfs_graph4.print_graph()

print("\nBFS starting from vertex 'A':")
visited_bfs4 = dfs_graph4.bfs('A')
print("Visited vertices in BFS order:", visited_bfs4)

print("\nDFS starting from vertex 'A':")
visited_dfs4 = dfs_graph4.dfs('A')
print("Visited vertices in DFS order:", visited_dfs4)



#  DFS Test 5: Compare BFS vs DFS on same graph 
print("\n--- DFS Test 5: BFS vs DFS Comparison ---")
print("Graph: A connected to B and C, B connected to D and E")
comparison_graph = Graph(directed=False)
for v in ['A', 'B', 'C', 'D', 'E']:
    comparison_graph.add_vertex(v)
comparison_graph.add_edge('A', 'B')
comparison_graph.add_edge('A', 'C')
comparison_graph.add_edge('B', 'D')
comparison_graph.add_edge('B', 'E')

print("\nBFS order (level-by-level):", comparison_graph.bfs('A'))
print("DFS order (deep-first):", comparison_graph.dfs('A'))

print("Task 3 Complete!")
