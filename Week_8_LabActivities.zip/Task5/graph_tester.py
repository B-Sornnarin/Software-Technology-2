# graph_tester.py - Task 5: Weighted and Directed Graphs

from graph import Graph

print("TASK 5: Weighted and Directed Graphs")
print()

# Test 1: Weighted Directed Graph
print("--- Test 1: Weighted Directed Graph ---")
wg = Graph(directed=True, weighted=True)

for v in ['A', 'B', 'C']:
    wg.add_vertex(v)

wg.add_edge('A', 'B', weight=15)
wg.add_edge('B', 'C', weight=34)
wg.add_edge('A', 'C', weight=50)

print("Weighted Directed Graph:")
wg.print_graph()
print()

# Test 2: Weighted Undirected Graph
print("--- Test 2: Weighted Undirected Graph ---")
wug = Graph(directed=False, weighted=True)

for v in ['A', 'B', 'C']:
    wug.add_vertex(v)

wug.add_edge('A', 'B', weight=15)
wug.add_edge('B', 'C', weight=34)

print("Weighted Undirected Graph:")
wug.print_graph()
print()

# Test 3: Directed Graph without weights
print("--- Test 3: Directed Graph (No Weights) ---")
dg = Graph(directed=True, weighted=False)

for v in ['A', 'B', 'C', 'D']:
    dg.add_vertex(v)

dg.add_edge('A', 'B')
dg.add_edge('A', 'C')
dg.add_edge('B', 'D')
dg.add_edge('C', 'D')

print("Directed Graph (unweighted):")
dg.print_graph()
print()

# Test 4: Accessing weights from weighted graph
print("--- Test 4: Accessing Edge Weights ---")
print("Weighted Directed Graph edges and their weights:")
for vertex in wg.graph:
    for neighbor in wg.graph[vertex]:
        weight = wg.weights.get((vertex, neighbor))
        print(f"  {vertex} -> {neighbor} : weight = {weight}")
print()

# Test 5: BFS and DFS on Weighted Directed Graph
print("--- Test 5: BFS and DFS on Weighted Directed Graph ---")
print("Note: BFS and DFS ignore weights - they only use graph structure")

print("\nWeighted Directed Graph (A->B:15, B->C:34, A->C:50):")
wg.print_graph()

print("\nBFS starting from 'A':", wg.bfs('A'))
print("DFS starting from 'A':", wg.dfs('A'))
print()

# Test 6: Adding edges with different weights
print("--- Test 6: Multiple Edges with Different Weights ---")
multi_weight = Graph(directed=True, weighted=True)

for v in ['X', 'Y', 'Z']:
    multi_weight.add_vertex(v)

multi_weight.add_edge('X', 'Y', weight=5)
multi_weight.add_edge('X', 'Y', weight=10)
multi_weight.add_edge('Y', 'Z', weight=20)

print("Graph with possible duplicate edges:")
multi_weight.print_graph()
print("Note: Adjacency list can have duplicates. In real graphs, you'd check first.")
print()

# Test 7: Removing edges in weighted graph
print("--- Test 7: Removing Edges in Weighted Graph ---")
remove_test = Graph(directed=True, weighted=True)

for v in ['A', 'B', 'C']:
    remove_test.add_vertex(v)

remove_test.add_edge('A', 'B', weight=15)
remove_test.add_edge('B', 'C', weight=34)
print("Before removal:")
remove_test.print_graph()

remove_test.remove_edge('A', 'B')
print("\nAfter removing edge A->B:")
remove_test.print_graph()

print()
print("Task 5 Complete!")
