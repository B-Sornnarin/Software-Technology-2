from tkinter import *
import math

class KochSnowflake:
    def __init__(self):
        window = Tk()
        window.title("Koch Snowflake")
        
        self.width = 400  # Smaller width to match the image
        self.height = 400
        
        self.canvas = Canvas(window, width=self.width, height=self.height, bg='white')
        self.canvas.pack()
        
        # Control frame
        frame1 = Frame(window)
        frame1.pack()
        
        Label(frame1, text="Enter an order: ").pack(side=LEFT)
        
        self.order = StringVar()
        self.order.set("0")  # Default to 0 as shown in image
        Entry(frame1, textvariable=self.order, justify=RIGHT, width=5).pack(side=LEFT)
        
        Button(frame1, text="Display",
               command=self.display).pack(side=LEFT)
        
        window.mainloop()
    
    def display(self):
        self.canvas.delete("all")
        
        try:
            order = int(self.order.get())
            
            # Calculate initial triangle points - adjusted for smaller canvas
            size = 150  # Smaller size to fit in 400x400 canvas
            center_x = self.width / 2
            center_y = self.height / 2
            
            # Calculate vertices of equilateral triangle
            points = []
            for i in range(3):
                angle = math.radians(90 + i * 120)  # Start from top
                x = center_x + size * math.cos(angle)
                y = center_y - size * math.sin(angle)
                points.append([x, y])
            
            # Generate the snowflake
            snowflake_points = []
            
            # Generate each side of the triangle
            for i in range(3):
                p1 = points[i]
                p2 = points[(i + 1) % 3]
                self.koch_curve(order, p1, p2, snowflake_points)
            
            # Draw the snowflake
            self.draw_snowflake(snowflake_points)
            
        except ValueError:
            pass
    
    def koch_curve(self, order, p1, p2, points_list):
        """Generate Koch curve points recursively"""
        if order == 0:
            # Add the start point if list is empty, otherwise just add endpoint
            if not points_list:
                points_list.append(p1)
            points_list.append(p2)
        else:
            # Calculate intermediate points
            dx = p2[0] - p1[0]
            dy = p2[1] - p1[1]
            
            # Points at 1/3 and 2/3 along the line
            pA = [p1[0] + dx / 3, p1[1] + dy / 3]
            pB = [p1[0] + 2 * dx / 3, p1[1] + 2 * dy / 3]
            
            # Calculate the peak point (equilateral triangle)
            angle = math.radians(60)
            vx = dx / 3
            vy = dy / 3
            peak_x = pA[0] + vx * math.cos(angle) - vy * math.sin(angle)
            peak_y = pA[1] + vx * math.sin(angle) + vy * math.cos(angle)
            pPeak = [peak_x, peak_y]
            
            # Recursively generate each segment
            self.koch_curve(order - 1, p1, pA, points_list)
            self.koch_curve(order - 1, pA, pPeak, points_list)
            self.koch_curve(order - 1, pPeak, pB, points_list)
            self.koch_curve(order - 1, pB, p2, points_list)
    
    def draw_snowflake(self, points):
        """Draw the snowflake from the list of points"""
        if len(points) < 2:
            return
        
        for i in range(len(points) - 1):
            self.canvas.create_line(
                points[i][0], points[i][1],
                points[i + 1][0], points[i + 1][1],
                fill="black", width=1 
            )

# Create GUI
if __name__ == "__main__":
    KochSnowflake()
