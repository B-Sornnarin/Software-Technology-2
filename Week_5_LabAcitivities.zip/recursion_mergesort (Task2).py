# task2_merge_sort_benchmark.py
import random
import timeit
import matplotlib.pyplot as plt

# MERGE SORT IMPLEMENTATION
def merge_sort(array):
    if len(array) <= 1:
        return array
    else:
        left_split = array[:len(array)//2]
        right_split = array[len(array)//2:]

        left = merge_sort(left_split)
        right = merge_sort(right_split)        

        return merge(left, right)

def merge(left, right):
    merged = []
    left_pointer = 0
    right_pointer = 0
    merging = True

    while merging:
        left_element = left[left_pointer]
        right_element = right[right_pointer]

        if left_element < right_element:
            merged.append(left_element)
            left_pointer += 1
        elif right_element < left_element:
            merged.append(right_element)
            right_pointer += 1
        elif right_element == left_element:
            merged.append(right_element)
            merged.append(left_element)
            left_pointer += 1
            right_pointer += 1

        if left_pointer >= len(left):
            merged.extend(right[right_pointer:])
            merging = False
        elif right_pointer >= len(right):
            merged.extend(left[left_pointer:])
            merging = False

    return merged

# INSERTION SORT
def insertion_sort(arr):
    for i in range(1, len(arr)):
        current_element = arr[i]
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = current_element
    return arr

# TEST FUNCTION
def test_sorting_algorithms():
    # Test different data sizes
    data_sizes = [10, 50, 100, 500, 1000, 2000, 5000]

    print(f"{'Data Size':<12} {'Merge Sort (s)':<18} {'Insertion Sort (s)':<18} {'Speedup':<12}")
    
    merge_times = []
    insertion_times = []
    
    for size in data_sizes:
        # Generate random test data
        test_data = [random.randint(1, 10000) for _ in range(size)]
        
        # Time Merge Sort
        merge_time = timeit.timeit(
            lambda: merge_sort(test_data.copy()), 
            number=5
        ) / 5  # Average of 5 runs
        
        # Time Insertion Sort (fewer runs for larger sizes to avoid waiting)
        runs = max(1, min(5, 1000 // size))
        insertion_time = timeit.timeit(
            lambda: insertion_sort(test_data.copy()), 
            number=runs
        ) / runs
        
        merge_times.append(merge_time)
        insertion_times.append(insertion_time)
        
        speedup = insertion_time / merge_time if merge_time > 0 else 0
        
        print(f"{size:<12} {merge_time:<18.6f} {insertion_time:<18.6f} {speedup:<12.2f}x")
    
    # Optional: Plot the results if matplotlib is available
    try:
        plt.figure(figsize=(10, 6))
        plt.plot(data_sizes, merge_times, 'b-o', label='Merge Sort')
        plt.plot(data_sizes, insertion_times, 'r-s', label='Insertion Sort')
        plt.xlabel('Data Size')
        plt.ylabel('Time (seconds)')
        plt.title('Merge Sort vs Insertion Sort Performance')
        plt.legend()
        plt.grid(True)
        plt.savefig('sorting_comparison.png')
        plt.show()
        print("\nPerformance graph saved as 'sorting_comparison.png'")
    except:
        print("\nMatplotlib not available for graphing")

if __name__ == "__main__":
    test_sorting_algorithms()
