# TowerOfHanoi_Part2.py
move_count = 0

def main():
    global move_count
    n = eval(input("Enter number of disks: "))
    move_count = 0
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')
    print("Number of moves is", move_count)

def moveDisks(n, fromTower, toTower, auxTower):
    global move_count
    if n == 1:
        move_count += 1
        # Removed print statement
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        move_count += 1
        moveDisks(n - 1, auxTower, toTower, fromTower)

main()
