# task1_recursion_vs_iteration.py
import timeit
import sys

# Increase recursion limit for larger numbers
sys.setrecursionlimit(10000)

# RECURSIVE IMPLEMENTATIONS
def sum_recursive(n):
    """Recursive sum of natural numbers"""
    if n == 1:
        return 1
    else:
        return n + sum_recursive(n - 1)

def fibonacci_recursive(n):
    """Recursive Fibonacci"""
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fibonacci_recursive(n - 1) + fibonacci_recursive(n - 2)

def factorial_recursive(n):
    """Recursive factorial"""
    if n == 0:
        return 1
    else:
        return n * factorial_recursive(n - 1)

# ITERATIVE IMPLEMENTATIONS
def sum_iterative(n):
    """Iterative sum of natural numbers"""
    total = 0
    for i in range(1, n + 1):
        total += i
    return total

def fibonacci_iterative(n):
    """Iterative Fibonacci"""
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    
    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b

def factorial_iterative(n):
    """Iterative factorial"""
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result

# TESTING AND COMPARISON
def test_and_compare():
    test_sizes = [5, 10, 15, 20, 25, 30, 35]
    print("COMPARISON OF RECURSIVE VS ITERATIVE IMPLEMENTATIONS")
    
    # Test Sum of Natural Numbers
    print("\n--- SUM OF NATURAL NUMBERS ---")
    print(f"{'n':<10} {'Recursive':<15} {'Iterative':<15} {'Recursive Time':<20} {'Iterative Time':<20}")
    
    for n in test_sizes:
        # Test correctness
        rec_result = sum_recursive(n)
        it_result = sum_iterative(n)
        
        # Test performance
        rec_time = timeit.timeit(lambda: sum_recursive(n), number=1000)
        it_time = timeit.timeit(lambda: sum_iterative(n), number=1000)
        
        print(f"{n:<10} {rec_result:<15} {it_result:<15} {rec_time:<20.10f} {it_time:<20.10f}")
    
    # Test Factorial
    print("\n--- FACTORIAL ---")
    print(f"{'n':<10} {'Recursive':<15} {'Iterative':<15} {'Recursive Time':<20} {'Iterative Time':<20}")
    
    factorial_sizes = [5, 10, 15, 20]
    for n in factorial_sizes:
        rec_result = factorial_recursive(n)
        it_result = factorial_iterative(n)
        
        rec_time = timeit.timeit(lambda: factorial_recursive(n), number=1000)
        it_time = timeit.timeit(lambda: factorial_iterative(n), number=1000)
        
        print(f"{n:<10} {rec_result:<15} {it_result:<15} {rec_time:<20.10f} {it_time:<20.10f}")
    
    # Test Fibonacci (smaller sizes due to exponential complexity)
    print("\n--- FIBONACCI ---")
    print(f"{'n':<10} {'Recursive':<15} {'Iterative':<15} {'Recursive Time':<20} {'Iterative Time':<20}")
    
    fib_sizes = [5, 10, 15, 20, 25, 30, 35]
    for n in fib_sizes:
        rec_result = fibonacci_recursive(n)
        it_result = fibonacci_iterative(n)
        
        rec_time = timeit.timeit(lambda: fibonacci_recursive(n), number=10)  # Fewer iterations for recursive
        it_time = timeit.timeit(lambda: fibonacci_iterative(n), number=1000)
        
        print(f"{n:<10} {rec_result:<15} {it_result:<15} {rec_time:<20.10f} {it_time:<20.10f}")


if __name__ == "__main__":
    test_and_compare()
