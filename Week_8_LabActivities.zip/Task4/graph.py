# graph.py

class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph:
            self.graph[vertex1].append(vertex2)
            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight
            if not self.directed:
                self.graph[vertex2].append(vertex1)
                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph:
            if vertex2 in self.graph[vertex1]:
                self.graph[vertex1].remove(vertex2)
            if not self.directed:
                if vertex1 in self.graph[vertex2]:
                    self.graph[vertex2].remove(vertex1)
            if self.weighted:
                self.weights.pop((vertex1, vertex2), None)
                if not self.directed:
                    self.weights.pop((vertex2, vertex1), None)

    def remove_vertex(self, vertex):
        if vertex in self.graph:
            for other in list(self.graph.keys()):
                if vertex in self.graph[other]:
                    self.graph[other].remove(vertex)
            del self.graph[vertex]
            if self.weighted:
                keys_to_remove = [key for key in self.weights if vertex in key]
                for key in keys_to_remove:
                    self.weights.pop(key, None)

    def bfs(self, start_vertex):
        visited = []
        queue = [start_vertex]
        while queue:
            vertex = queue.pop(0)
            if vertex not in visited:
                visited.append(vertex)
                for neighbor in self.graph[vertex]:
                    if neighbor not in visited and neighbor not in queue:
                        queue.append(neighbor)
        return visited

    def dfs(self, start_vertex):
        visited = []
        stack = [start_vertex]
        while stack:
            vertex = stack.pop()
            if vertex not in visited:
                visited.append(vertex)
                for neighbor in reversed(self.graph[vertex]):
                    if neighbor not in visited:
                        stack.append(neighbor)
        return visited

    def has_undirected_cycle(self):
        """Detect cycle in undirected graph using DFS"""
        if self.directed:
            print("This method is for undirected graphs only")
            return False
        
        visited = set()
        
        def dfs(current, parent):
            visited.add(current)
            
            for neighbor in self.graph[current]:
                if neighbor not in visited:
                    if dfs(neighbor, current):
                        return True
                elif neighbor != parent:
                    return True
            return False
        
        for vertex in self.graph:
            if vertex not in visited:
                if dfs(vertex, None):
                    return True
        return False

    def print_graph(self):
        if self.weighted:
            print("Graph (Weighted:", self.weighted, "Directed:", self.directed, ")")
            for vertex in self.graph:
                for neighbor in self.graph[vertex]:
                    weight = self.weights.get((vertex, neighbor), 0)
                    print(f"  {vertex} -> {neighbor} (weight: {weight})")
        else:
            print("Graph (Weighted:", self.weighted, "Directed:", self.directed, ")")
            for vertex in self.graph:
                print(f"  {vertex}: {self.graph[vertex]}")
