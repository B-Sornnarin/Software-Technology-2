import tkinter as tk
from tkinter import messagebox

NODE_WIDTH = 80
NODE_HEIGHT = 40
HORIZONTAL_GAP = 15
CANVAS_WIDTH = 800
CANVAS_HEIGHT = 200

class QueueVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Queue Visualizer")

        self.queue = []  # Using list as queue (FIFO)

        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg='white')
        self.canvas.pack(pady=20)

        control_frame = tk.Frame(root)
        control_frame.pack()

        # Push button - adds to queue
        tk.Label(control_frame, text="Push Value:").grid(row=0, column=0)
        self.push_entry = tk.Entry(control_frame, width=10)
        self.push_entry.grid(row=0, column=1)

        push_btn = tk.Button(control_frame, text="Push", command=self.push_value)
        push_btn.grid(row=0, column=2, padx=5)

        # Pop button - removes from queue
        pop_btn = tk.Button(control_frame, text="Pop", command=self.pop_value)
        pop_btn.grid(row=1, column=2, pady=5)

        self.status_label = tk.Label(root, text="", fg="blue", font=("Arial", 12))
        self.status_label.pack(pady=5)

        # Pre-populate queue with [10, 20, 30, 40]
        for v in [10, 20, 30, 40]:
            self.queue.append(v)
        self.draw_queue()

    def draw_node(self, x, y, data, highlight=False):
        """Draw a single node rectangle with value"""
        fill_color = "yellow" if highlight else "lightblue"
        outline_color = "red" if highlight else "black"
        width = 3 if highlight else 2
        
        self.canvas.create_rectangle(x, y, x + NODE_WIDTH, y + NODE_HEIGHT,
                                     fill=fill_color, outline=outline_color, width=width)
        self.canvas.create_text(x + NODE_WIDTH/2, y + NODE_HEIGHT/2, 
                               text=str(data), font=("Arial", 16))

    def draw_arrow(self, x1, y1, x2, y2):
        """Draw arrow from one node to the next"""
        start_x = x1 + NODE_WIDTH
        start_y = y1 + NODE_HEIGHT // 2
        end_x = x2
        end_y = y2 + NODE_HEIGHT // 2
        self.canvas.create_line(start_x, start_y, end_x, end_y, arrow=tk.LAST, width=2)

    def draw_queue(self, highlight_index=None):
        """Draw the queue horizontally"""
        self.canvas.delete("all")
        
        if not self.queue:
            self.canvas.create_text(CANVAS_WIDTH // 2, CANVAS_HEIGHT // 2,
                                   text="Queue is empty", font=("Arial", 12), fill="gray")
            return
        
        # Calculate starting position
        total_width = len(self.queue) * (NODE_WIDTH + HORIZONTAL_GAP) - HORIZONTAL_GAP
        start_x = (CANVAS_WIDTH - total_width) // 2
        y = (CANVAS_HEIGHT - NODE_HEIGHT) // 2
        
        positions = []
        
        # Draw nodes
        for i, val in enumerate(self.queue):
            x = start_x + i * (NODE_WIDTH + HORIZONTAL_GAP)
            highlight = (i == highlight_index)
            self.draw_node(x, y, val, highlight)
            positions.append((x, y))
        

        for i in range(len(positions) - 1):
            x1, y1 = positions[i]
            x2, y2 = positions[i + 1]
            self.draw_arrow(x1, y1, x2, y2)
        

        if self.queue:

            self.canvas.create_text(positions[0][0] - 15, y + NODE_HEIGHT // 2, 
                                   text="FRONT ←", font=("Arial", 10, "bold"), fill="red")

            self.canvas.create_text(positions[-1][0] + NODE_WIDTH + 15, y + NODE_HEIGHT // 2, 
                                   text="→ REAR", font=("Arial", 10, "bold"), fill="red")

    def push_value(self):
        """Push (add) value to the REAR of queue"""
        try:
            val = int(self.push_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter an integer value to push.")
            return
        
        self.queue.append(val) 
        self.push_entry.delete(0, tk.END)
        self.status_label.config(text=f"Pushed {val} to queue (added to REAR)")
        self.draw_queue()
        

        if len(self.queue) > 0:
            self.root.after(200, lambda: self.draw_queue(highlight_index=len(self.queue)-1))
            self.root.after(800, lambda: self.draw_queue())

    def pop_value(self):
        """Pop (remove) value from the FRONT of queue"""
        if len(self.queue) == 0:
            messagebox.showinfo("Empty Queue", "Queue is empty. Cannot pop.")
            return
        
        val = self.queue.pop(0) 
        self.status_label.config(text=f"Popped {val} from queue (removed from FRONT)")
        self.draw_queue()
        

        if len(self.queue) > 0:
            self.root.after(200, lambda: self.draw_queue(highlight_index=0))
            self.root.after(800, lambda: self.draw_queue())

if __name__ == "__main__":
    root = tk.Tk()
    app = QueueVisualizer(root)
    

    app.queue.append(50)
    app.draw_queue()
    
    root.mainloop()
