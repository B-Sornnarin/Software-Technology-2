# graph_tester.py
from graph import Graph

print("TASK 1: Basic Graph Operations")

# ===== Test 1: Basic Undirected Graph =====
print("\n--- Test 1: Undirected Graph ---")
g = Graph(directed=False, weighted=False)

# Add vertices
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')
print("After adding vertices A, B, C, D:")
g.print_graph()

# Add edges
g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')
print("\nAfter adding edges A-B, B-C, C-D:")
g.print_graph()

# Remove an edge
g.remove_edge('B', 'C')
print("\nAfter removing edge B-C:")
g.print_graph()

# Remove a vertex
g.remove_vertex('D')
print("\nAfter removing vertex D:")
g.print_graph()



# ===== Test 2: Directed Graph =====
print("\n--- Test 2: Directed Graph ---")
g2 = Graph(directed=True, weighted=False)

# Add vertices
g2.add_vertex('A')
g2.add_vertex('B')
g2.add_vertex('C')
g2.add_vertex('D')
print("After adding vertices A, B, C, D:")
g2.print_graph()

# Add edges
g2.add_edge('A', 'B')
g2.add_edge('B', 'C')
g2.add_edge('C', 'D')
print("\nAfter adding edges A->B, B->C, C->D:")
g2.print_graph()

# Remove an edge
g2.remove_edge('B', 'C')
print("\nAfter removing edge B->C:")
g2.print_graph()

# Remove a vertex
g2.remove_vertex('D')
print("\nAfter removing vertex D:")
g2.print_graph()



# ===== Test 3: Weighted Directed Graph =====
print("\n--- Test 3: Weighted Directed Graph ---")
g3 = Graph(directed=True, weighted=True)

# Add vertices
g3.add_vertex('A')
g3.add_vertex('B')
g3.add_vertex('C')
print("After adding vertices A, B, C:")
g3.print_graph()

# Add weighted edges
g3.add_edge('A', 'B', 15)
g3.add_edge('B', 'C', 34)
print("\nAfter adding edges A->B (15), B->C (34):")
g3.print_graph()


print("TASK 2: BFS Traversal")


# ===== BFS Test 1: Simple linear graph =====
print("\n--- BFS Test 1: Linear Graph (A-B-C-D) ---")
bfs_graph1 = Graph(directed=False)
for v in ['A', 'B', 'C', 'D']:
    bfs_graph1.add_vertex(v)
bfs_graph1.add_edge('A', 'B')
bfs_graph1.add_edge('B', 'C')
bfs_graph1.add_edge('C', 'D')

print("Graph structure:")
bfs_graph1.print_graph()

print("\nBFS starting from vertex 'A':")
visited_bfs = bfs_graph1.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)



# ===== BFS Test 2: Graph with branches =====
print("\n--- BFS Test 2: Graph with Branches ---")
bfs_graph2 = Graph(directed=False)
for v in ['A', 'B', 'C', 'D', 'E', 'F']:
    bfs_graph2.add_vertex(v)
bfs_graph2.add_edge('A', 'B')
bfs_graph2.add_edge('A', 'C')
bfs_graph2.add_edge('B', 'D')
bfs_graph2.add_edge('B', 'E')
bfs_graph2.add_edge('C', 'F')

print("Graph structure:")
bfs_graph2.print_graph()

print("\nBFS starting from vertex 'A':")
visited_bfs2 = bfs_graph2.bfs('A')
print("Visited vertices in BFS order:", visited_bfs2)



# ===== BFS Test 3: Graph with cycle =====
print("\n--- BFS Test 3: Graph with Cycle (Triangle) ---")
bfs_graph3 = Graph(directed=False)
for v in ['A', 'B', 'C']:
    bfs_graph3.add_vertex(v)
bfs_graph3.add_edge('A', 'B')
bfs_graph3.add_edge('B', 'C')
bfs_graph3.add_edge('C', 'A')  # Creates a cycle

print("Graph structure:")
bfs_graph3.print_graph()

print("\nBFS starting from vertex 'A':")
visited_bfs3 = bfs_graph3.bfs('A')
print("Visited vertices in BFS order:", visited_bfs3)



# ===== BFS Test 4: Directed graph =====
print("\n--- BFS Test 4: Directed Graph (A->B, A->C, B->D) ---")
bfs_graph4 = Graph(directed=True)
for v in ['A', 'B', 'C', 'D']:
    bfs_graph4.add_vertex(v)
bfs_graph4.add_edge('A', 'B')
bfs_graph4.add_edge('A', 'C')
bfs_graph4.add_edge('B', 'D')

print("Graph structure:")
bfs_graph4.print_graph()

print("\nBFS starting from vertex 'A':")
visited_bfs4 = bfs_graph4.bfs('A')
print("Visited vertices in BFS order:", visited_bfs4)


print("Task 2 Complete!")

