# graph_visualizer.py

from graph import Graph
import tkinter as tk
import math

class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()
        self.title("Graph Visualizer")
        self.geometry("500x550")
        
        self.graph = graph
        self.canvas = tk.Canvas(self, width=400, height=400, bg='white')
        self.canvas.pack(pady=10)
        
        self.vertex_positions = {}
        self.node_radius = 20
        self.spacing = 120
        self.center = (200, 200)
        
        # Control buttons
        control_frame = tk.Frame(self)
        control_frame.pack(pady=5)
        
        btn_bfs = tk.Button(control_frame, text="Run BFS", command=self.run_bfs)
        btn_bfs.pack(side=tk.LEFT, padx=5)
        
        btn_dfs = tk.Button(control_frame, text="Run DFS", command=self.run_dfs)
        btn_dfs.pack(side=tk.LEFT, padx=5)
        
        btn_reset = tk.Button(control_frame, text="Reset Colors", command=self.reset_colors)
        btn_reset.pack(side=tk.LEFT, padx=5)
        
        # Info label
        self.info_label = tk.Label(self, text="", font=("Arial", 10))
        self.info_label.pack(pady=5)
        
        self.draw_graph()
    
    def draw_graph(self):
        """Draw the graph on the canvas"""
        self.canvas.delete("all")
        self.vertex_positions.clear()
        
        vertices = list(self.graph.graph.keys())
        n = len(vertices)
        if n == 0:
            return
        
        angle_gap = 360 / n
        cx, cy = self.center
        
        # Draw edges first (so they appear behind vertices)
        for i, v in enumerate(vertices):
            angle = i * angle_gap
            x = cx + self.spacing * math.cos(math.radians(angle))
            y = cy + self.spacing * math.sin(math.radians(angle))
            self.vertex_positions[v] = (x, y)
        
        # Draw edges
        for v in vertices:
            x1, y1 = self.vertex_positions[v]
            for neighbor in self.graph.graph[v]:
                x2, y2 = self.vertex_positions[neighbor]
                
                # Calculate line start and end points (stop at circle edges)
                dx, dy = x2 - x1, y2 - y1
                dist = math.sqrt(dx*dx + dy*dy)
                if dist == 0:
                    continue
                
                offset_x = dx / dist * self.node_radius
                offset_y = dy / dist * self.node_radius
                start_x = x1 + offset_x
                start_y = y1 + offset_y
                end_x = x2 - offset_x
                end_y = y2 - offset_y
                
                # Draw line with arrow if directed
                if self.graph.directed:
                    self.canvas.create_line(start_x, start_y, end_x, end_y, 
                                           arrow=tk.LAST, width=2, fill='gray')
                else:
                    self.canvas.create_line(start_x, start_y, end_x, end_y, 
                                           width=2, fill='gray')
                
                # Draw weight if weighted
                if self.graph.weighted:
                    weight = self.graph.weights.get((v, neighbor), '')
                    if weight:
                        mid_x, mid_y = (start_x + end_x) / 2, (start_y + end_y) / 2
                        self.canvas.create_text(mid_x, mid_y, text=str(weight), 
                                               fill='red', font=("Arial", 10))
        
        # Draw vertices (on top of edges)
        for v, (x, y) in self.vertex_positions.items():
            self.canvas.create_oval(x - self.node_radius, y - self.node_radius,
                                   x + self.node_radius, y + self.node_radius,
                                   fill='lightblue', outline='black', width=2)
            self.canvas.create_text(x, y, text=v, font=("Arial", 12, "bold"))
    
    def reset_colors(self):
        """Reset all vertices to lightblue"""
        # Redraw the entire graph to reset colors
        self.draw_graph()
        self.info_label.config(text="Colors reset")
    
    def highlight_vertex(self, vertex, color):
        """Highlight a specific vertex with given color"""
        # Find and highlight the vertex
        for item in self.canvas.find_all():
            # Check if this is a vertex oval by getting its tags or coordinates
            coords = self.canvas.coords(item)
            if len(coords) == 4:  # Oval has 4 coordinates
                x = (coords[0] + coords[2]) / 2
                y = (coords[1] + coords[3]) / 2
                # Check if this oval contains our vertex
                if vertex in self.vertex_positions:
                    vx, vy = self.vertex_positions[vertex]
                    if abs(x - vx) < 5 and abs(y - vy) < 5:
                        self.canvas.itemconfig(item, fill=color)
                        break
        self.update()
    
    def run_bfs(self):
        """Run BFS traversal and animate"""
        self.reset_colors()
        vertices = list(self.graph.graph.keys())
        if not vertices:
            self.info_label.config(text="Graph is empty")
            return
        
        start_vertex = 'A' if 'A' in vertices else vertices[0]
        visited = []
        queue = [start_vertex]
        
        self.info_label.config(text=f"BFS starting from {start_vertex}...")
        
        def step():
            if queue:
                vertex = queue.pop(0)
                if vertex not in visited:
                    visited.append(vertex)
                    self.highlight_vertex(vertex, 'orange')
                    self.info_label.config(text=f"BFS visiting: {vertex}")
                    
                    for neighbor in self.graph.graph[vertex]:
                        if neighbor not in visited and neighbor not in queue:
                            queue.append(neighbor)
                    
                    self.after(700, step)
                else:
                    step()
            else:
                self.info_label.config(text=f"BFS complete. Order: {visited}")
        
        step()
    
    def run_dfs(self):
        """Run DFS traversal and animate"""
        self.reset_colors()
        vertices = list(self.graph.graph.keys())
        if not vertices:
            self.info_label.config(text="Graph is empty")
            return
        
        start_vertex = 'A' if 'A' in vertices else vertices[0]
        visited = []
        stack = [start_vertex]
        
        self.info_label.config(text=f"DFS starting from {start_vertex}...")
        
        def step():
            if stack:
                vertex = stack.pop()
                if vertex not in visited:
                    visited.append(vertex)
                    self.highlight_vertex(vertex, 'purple')
                    self.info_label.config(text=f"DFS visiting: {vertex}")
                    
                    # Add neighbors in reverse order for natural DFS order
                    for neighbor in reversed(self.graph.graph[vertex]):
                        if neighbor not in visited:
                            stack.append(neighbor)
                    
                    self.after(700, step)
                else:
                    step()
            else:
                self.info_label.config(text=f"DFS complete. Order: {visited}")
        
        step()


if __name__ == "__main__":
    # Create a sample graph
    g = Graph(directed=True, weighted=True)
    
    g.add_vertex('A')
    g.add_vertex('B')
    g.add_vertex('C')
    g.add_vertex('D')
    
    g.add_edge('A', 'B', 10)
    g.add_edge('B', 'C', 20)
    g.add_edge('C', 'D', 30)
    g.add_edge('A', 'D', 40)
    g.add_edge('A', 'C', 50)
    
    app = GraphVisualizer(g)
    app.mainloop()
