# graph_tester.py
from graph import Graph

print("TASK 1: Basic Graph Operations")

# Test 1: Basic Undirected Graph
print("\n--- Test 1: Undirected Graph ---")
g = Graph(directed=False, weighted=False)

# Add vertices
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')
print("After adding vertices A, B, C, D:")
g.print_graph()

# Add edges
g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')
print("\nAfter adding edges A-B, B-C, C-D:")
g.print_graph()

# Remove an edge
g.remove_edge('B', 'C')
print("\nAfter removing edge B-C:")
g.print_graph()

# Remove a vertex
g.remove_vertex('D')
print("\nAfter removing vertex D:")
g.print_graph()



# Test 2: Directed Graph
print("\n--- Test 2: Directed Graph ---")
g2 = Graph(directed=True, weighted=False)

# Add vertices
g2.add_vertex('A')
g2.add_vertex('B')
g2.add_vertex('C')
g2.add_vertex('D')
print("After adding vertices A, B, C, D:")
g2.print_graph()

# Add edges
g2.add_edge('A', 'B')
g2.add_edge('B', 'C')
g2.add_edge('C', 'D')
print("\nAfter adding edges A->B, B->C, C->D:")
g2.print_graph()

# Remove an edge
g2.remove_edge('B', 'C')
print("\nAfter removing edge B->C:")
g2.print_graph()

# Remove a vertex
g2.remove_vertex('D')
print("\nAfter removing vertex D:")
g2.print_graph()


# Test 3: Weighted Directed Graph
print("\n--- Test 3: Weighted Directed Graph ---")
g3 = Graph(directed=True, weighted=True)

# Add vertices
g3.add_vertex('A')
g3.add_vertex('B')
g3.add_vertex('C')
print("After adding vertices A, B, C:")
g3.print_graph()

# Add weighted edges
g3.add_edge('A', 'B', 15)
g3.add_edge('B', 'C', 34)
print("\nAfter adding edges A->B (15), B->C (34):")
g3.print_graph()


print("Task 1 Complete!")
