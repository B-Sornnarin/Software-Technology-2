# graph.py

class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}  # Initialize an empty dictionary to store the adjacency list
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []  # Add a new vertex with an empty list of edges

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph:  # Check that vertices are present
            # store vertex and weight as a tuple
            self.graph[vertex1].append(vertex2)
            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight
            if not self.directed:  # In the case of an undirected graph, append in both directions
                self.graph[vertex2].append(vertex1)
                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph:
            # Remove vertex2 from vertex1's adjacency list
            if vertex2 in self.graph[vertex1]:
                self.graph[vertex1].remove(vertex2)
            # If undirected, also remove vertex1 from vertex2's adjacency list
            if not self.directed:
                if vertex1 in self.graph[vertex2]:
                    self.graph[vertex2].remove(vertex1)
            # Remove weight if it exists
            if self.weighted:
                self.weights.pop((vertex1, vertex2), None)
                if not self.directed:
                    self.weights.pop((vertex2, vertex1), None)

    def remove_vertex(self, vertex):
        if vertex in self.graph:
            # Remove all edges pointing to this vertex
            for other in list(self.graph.keys()):
                if vertex in self.graph[other]:
                    self.graph[other].remove(vertex)
            # Remove the vertex itself
            del self.graph[vertex]
            # Remove related weights
            if self.weighted:
                keys_to_remove = [key for key in self.weights if vertex in key]
                for key in keys_to_remove:
                    self.weights.pop(key, None)

    #BFS METHOD 
    def bfs(self, start_vertex):
        """Breadth First Search traversal starting from start_vertex"""
        visited = []  # List to store visited vertices in order
        queue = [start_vertex]  # Queue for BFS (using list as queue)
        
        while queue:
            vertex = queue.pop(0)  # Remove first element from queue
            if vertex not in visited:
                visited.append(vertex)  # Mark as visited
                # Add all neighbors to the queue
                for neighbor in self.graph[vertex]:
                    if neighbor not in visited and neighbor not in queue:
                        queue.append(neighbor)
        
        return visited

    #ADD DFS
    def dfs(self, start_vertex):
        """Depth First Search traversal starting from start_vertex using a stack"""
        visited = []  # List to store visited vertices in order
        stack = [start_vertex]  # Stack for DFS (using list as stack)
        
        while stack:
            vertex = stack.pop()  # Remove last element from stack (LIFO)
            if vertex not in visited:
                visited.append(vertex)  # Mark as visited
                # Add all neighbors to the stack (reverse order for natural DFS order)
                for neighbor in reversed(self.graph[vertex]):
                    if neighbor not in visited:
                        stack.append(neighbor)
        
        return visited

    def print_graph(self):
        if self.weighted:
            print("Graph (Weighted:", self.weighted, "Directed:", self.directed, ")")
            for vertex in self.graph:
                for neighbor in self.graph[vertex]:
                    weight = self.weights.get((vertex, neighbor), 0)
                    print(f"  {vertex} -> {neighbor} (weight: {weight})")
        else:
            print("Graph (Weighted:", self.weighted, "Directed:", self.directed, ")")
            for vertex in self.graph:
                print(f"  {vertex}: {self.graph[vertex]}")
