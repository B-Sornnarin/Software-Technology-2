# graph_tester.py - Task 4: Cycle Detection

from graph import Graph


print("TASK 4: Cycle Detection in Undirected Graphs")


# Test 1: Graph WITH a cycle (Triangle: A-B-C-A)
print("\n--- Test 1: Graph WITH a Cycle (Triangle) ---")
cycle_graph = Graph(directed=False)
for v in ['A', 'B', 'C']:
    cycle_graph.add_vertex(v)
cycle_graph.add_edge('A', 'B')
cycle_graph.add_edge('B', 'C')
cycle_graph.add_edge('C', 'A')  # This creates a cycle

print("Graph structure:")
cycle_graph.print_graph()

print("\nDoes cycle_graph have a cycle?", cycle_graph.has_undirected_cycle())



# Test 2: Graph WITHOUT a cycle (Linear chain: X-Y-Z)
print("\n--- Test 2: Graph WITHOUT a Cycle (Linear Chain) ---")
acyclic_graph = Graph(directed=False)
for v in ['X', 'Y', 'Z']:
    acyclic_graph.add_vertex(v)
acyclic_graph.add_edge('X', 'Y')
acyclic_graph.add_edge('Y', 'Z')

print("Graph structure:")
acyclic_graph.print_graph()

print("\nDoes acyclic_graph have a cycle?", acyclic_graph.has_undirected_cycle())



# Test 3: Graph with 4 vertices forming a square (has cycle)
print("\n--- Test 3: Graph WITH a Cycle (Square: A-B-C-D-A) ---")
square_graph = Graph(directed=False)
for v in ['A', 'B', 'C', 'D']:
    square_graph.add_vertex(v)
square_graph.add_edge('A', 'B')
square_graph.add_edge('B', 'C')
square_graph.add_edge('C', 'D')
square_graph.add_edge('D', 'A')  # This creates a cycle

print("Graph structure:")
square_graph.print_graph()

print("\nDoes square_graph have a cycle?", square_graph.has_undirected_cycle())



# Test 4: Tree graph (no cycle)
print("\n--- Test 4: Tree Graph (No Cycle) ---")
tree_graph = Graph(directed=False)
for v in ['A', 'B', 'C', 'D', 'E']:
    tree_graph.add_vertex(v)
tree_graph.add_edge('A', 'B')
tree_graph.add_edge('A', 'C')
tree_graph.add_edge('B', 'D')
tree_graph.add_edge('B', 'E')

print("Graph structure:")
tree_graph.print_graph()

print("\nDoes tree_graph have a cycle?", tree_graph.has_undirected_cycle())



# Test 5: Graph with multiple components (no cycle)
print("\n--- Test 5: Multiple Components (No Cycle) ---")
multi_graph = Graph(directed=False)
for v in ['A', 'B', 'C', 'D', 'E']:
    multi_graph.add_vertex(v)
multi_graph.add_edge('A', 'B')
multi_graph.add_edge('C', 'D')
# E is isolated

print("Graph structure:")
multi_graph.print_graph()

print("\nDoes multi_graph have a cycle?", multi_graph.has_undirected_cycle())



# Test 6: Graph with a cycle in one component
print("\n--- Test 6: Cycle in One Component ---")
component_cycle_graph = Graph(directed=False)
for v in ['A', 'B', 'C', 'D', 'E', 'F']:
    component_cycle_graph.add_vertex(v)
# Component 1: has cycle (A-B-C-A)
component_cycle_graph.add_edge('A', 'B')
component_cycle_graph.add_edge('B', 'C')
component_cycle_graph.add_edge('C', 'A')
# Component 2: no cycle (D-E-F)
component_cycle_graph.add_edge('D', 'E')
component_cycle_graph.add_edge('E', 'F')

print("Graph structure:")
component_cycle_graph.print_graph()


print("Task 4 Complete!")

